from django.urls import path

from markets.admin_portal.views_admin import (
    MarketActivateView,
    MarketClosureDeleteView,
    MarketClosureListCreateView,
    MarketDeactivateView,
    MarketDetailView,
    MarketEditImpactView,
    MarketGeocodeView,
    MarketListCreateView,
    MarketRequestApproveView,
    MarketRequestListView,
    MarketRequestRejectView,
)

urlpatterns = [
    path("admin/market-requests/", MarketRequestListView.as_view(), name="admin-market-request-list"),
    path(
        "admin/market-requests/<int:id>/approve/",
        MarketRequestApproveView.as_view(),
        name="admin-market-request-approve",
    ),
    path(
        "admin/market-requests/<int:id>/reject/",
        MarketRequestRejectView.as_view(),
        name="admin-market-request-reject",
    ),
    path("admin/markets/", MarketListCreateView.as_view(), name="admin-market-list"),
    path("admin/markets/geocode/", MarketGeocodeView.as_view(), name="admin-market-geocode"),
    path("admin/markets/<int:id>/", MarketDetailView.as_view(), name="admin-market-detail"),
    path(
        "admin/markets/<int:id>/impact/",
        MarketEditImpactView.as_view(),
        name="admin-market-impact",
    ),
    path(
        "admin/markets/<int:id>/deactivate/",
        MarketDeactivateView.as_view(),
        name="admin-market-deactivate",
    ),
    path(
        "admin/markets/<int:id>/activate/",
        MarketActivateView.as_view(),
        name="admin-market-activate",
    ),
    path(
        "admin/markets/<int:id>/closures/",
        MarketClosureListCreateView.as_view(),
        name="admin-market-closure-list",
    ),
    path(
        "admin/market-closures/<int:id>/",
        MarketClosureDeleteView.as_view(),
        name="admin-market-closure-detail",
    ),
]
